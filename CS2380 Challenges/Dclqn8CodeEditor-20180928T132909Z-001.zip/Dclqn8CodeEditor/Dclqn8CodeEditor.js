function sampleCSS() {
    'use strict';
    document.getElementById("css").value = "h4{color: lightblue; text-align: center;}\np{font-family: verdana, cursive; font-size: 35pt; text-align: right;}";
}

function sampleHTML() {
    'use strict';
    document.getElementById("html").value = "<h4>Hello World!</h4>\n<p>Welcome to me code editor application!</p>";
}

function launchHTML() {
    var htmlText = document.getElementById("html").value;
    document.getElementById("display").innerHTML = htmlText;
}

function toggleCSS() {
    var cssText = document.getElementById("css").value;
    var oldStyle = document.getElementById("default");
    var style = document.createElement('style');
    var head = document.head || document.getElementsByTagName('head')[0];

    style.type = 'text/css';

    if (oldStyle.href.match("Dclqn8CodeEditor.css")) {
        if (style.styleSheet) {
            style.styleSheet.cssText = cssText;
        } else {
            style.appendChild(document.createTextNode(cssText));
        }

        head.appendChild(style);

    } else {
        style.href = "Dclqn8CodeEditor.css";
    }
}

function clearCode() {
    document.getElementById("display").innerHTML = "";
    document.getElementById("display").style = "";
}
